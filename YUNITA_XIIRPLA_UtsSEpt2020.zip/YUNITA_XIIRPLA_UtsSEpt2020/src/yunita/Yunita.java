/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yunita;

/**
 *
 * @author test
 */
public class Yunita {

  
    public static void main(String[] args) {
        String alfabet  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#-";
        
        System.out.println(alfabet);
        System.out.print("Nama: "+alfabet.substring(24,25);
        System.out.print(alfabet.substring(20, 21));
        System.out.print(alfabet.substring(13, 14));
        System.out.print(alfabet.substring(8, 9));
        System.out.print(alfabet.substring(19, 20));
        System.out.print(alfabet.substring(0, 1));
        System.out.print(alfabet.substring(27, 28));
        System.out.print(alfabet.substring(10, 11));
        System.out.print(alfabet.substring(7, 8));
        System.out.print(alfabet.substring(0, 1));
        System.out.print(alfabet.substring(18, 19));
        System.out.print(alfabet.substring(0, 1));
        System.out.print(alfabet.substring(13, 14));
        System.out.print(alfabet.substring(0, 1));
        System.out.println(alfabet.substring(7, 8));
    }
    
}
